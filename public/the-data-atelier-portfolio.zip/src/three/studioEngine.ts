import * as THREE from 'three';

/**
 * Detects software WebGL (SwiftShader, llvmpipe, softpipe, WARP) from the GPU renderer string.
 */
export const isSoftwareGl = (() => {
  if (typeof document === 'undefined') return true;
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
})();

/**
 * Generates a tileable dark honed basalt & warm travertine architectural museum stone floor texture.
 */
export function createArchitecturalStoneTexture(): {
  map: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
} {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Deep architectural stone base (#101112)
  ctx.fillStyle = '#101112';
  ctx.fillRect(0, 0, 512, 512);

  // Subtle mineral clouding and honed travertine grain
  for (let i = 0; i < 42; i++) {
    const x = (i * 97) % 512;
    const y = (i * 151) % 512;
    const r = 45 + (i % 5) * 28;
    const grad = ctx.createRadialGradient(x, y, 4, x, y, r);
    grad.addColorStop(0, i % 2 === 0 ? 'rgba(29, 30, 32, 0.35)' : 'rgba(23, 24, 25, 0.35)');
    grad.addColorStop(1, 'rgba(16, 17, 18, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Fine mineral veining
  ctx.strokeStyle = 'rgba(185, 160, 120, 0.05)';
  ctx.lineWidth = 1.1;
  for (let i = 0; i < 12; i++) {
    ctx.beginPath();
    const startY = (i * 43) % 512;
    ctx.moveTo(0, startY);
    ctx.bezierCurveTo(160, startY + 28, 340, startY - 24, 512, startY + 12);
    ctx.stroke();
  }

  // Architectural stone slab joints with subtle champagne inlay hairline
  ctx.strokeStyle = 'rgba(10, 11, 12, 0.8)';
  ctx.lineWidth = 2;
  ctx.strokeRect(1, 1, 254, 254);
  ctx.strokeRect(257, 1, 254, 254);
  ctx.strokeRect(1, 257, 254, 254);
  ctx.strokeRect(257, 257, 254, 254);

  ctx.strokeStyle = 'rgba(185, 160, 120, 0.09)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, 256);
  ctx.lineTo(512, 256);
  ctx.moveTo(256, 0);
  ctx.lineTo(256, 512);
  ctx.stroke();

  const map = new THREE.CanvasTexture(canvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;
  map.repeat.set(4, 4);

  // Grayscale bump map for stone joints & pore micro-relief
  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = 256;
  bumpCanvas.height = 256;
  const bctx = bumpCanvas.getContext('2d')!;
  bctx.fillStyle = '#888888';
  bctx.fillRect(0, 0, 256, 256);
  bctx.strokeStyle = '#303030';
  bctx.lineWidth = 2;
  bctx.strokeRect(1, 1, 126, 126);
  bctx.strokeRect(129, 1, 126, 126);
  bctx.strokeRect(1, 129, 126, 126);
  bctx.strokeRect(129, 129, 126, 126);

  const bumpMap = new THREE.CanvasTexture(bumpCanvas);
  bumpMap.wrapS = THREE.RepeatWrapping;
  bumpMap.wrapT = THREE.RepeatWrapping;
  bumpMap.repeat.set(4, 4);

  return { map, bumpMap };
}

/**
 * Generates a warm dark American walnut wood grain texture for studio easels, frames, and palette boards.
 */
export function createWalnutWoodTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  const baseGrad = ctx.createLinearGradient(0, 0, 512, 512);
  baseGrad.addColorStop(0, '#261A13');
  baseGrad.addColorStop(0.5, '#1E140E');
  baseGrad.addColorStop(1, '#2A1D15');
  ctx.fillStyle = baseGrad;
  ctx.fillRect(0, 0, 512, 512);

  // Organic wood grain fibers
  for (let i = 0; i < 90; i++) {
    const y = (i / 90) * 512;
    ctx.strokeStyle =
      i % 3 === 0 ? 'rgba(14, 9, 6, 0.38)' : 'rgba(62, 43, 30, 0.22)';
    ctx.lineWidth = 1 + (i % 3);
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.bezierCurveTo(
      170,
      y + Math.sin(i * 0.4) * 14,
      340,
      y - Math.cos(i * 0.4) * 14,
      512,
      y + Math.sin(i * 0.2) * 8,
    );
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Generates a matte architectural Venetian plaster texture for museum gallery walls.
 */
export function createPlasterWallTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#171819';
  ctx.fillRect(0, 0, 512, 512);

  for (let i = 0; i < 36; i++) {
    const x = (i * 83) % 512;
    const y = (i * 137) % 512;
    const r = 60 + (i % 4) * 35;
    const grad = ctx.createRadialGradient(x, y, 8, x, y, r);
    grad.addColorStop(0, i % 2 === 0 ? 'rgba(29, 30, 32, 0.35)' : 'rgba(16, 17, 18, 0.35)');
    grad.addColorStop(1, 'rgba(23, 24, 25, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Subtle architectural reveal lines
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
  ctx.lineWidth = 1;
  ctx.strokeRect(16, 16, 480, 480);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Generates a procedural woven linen canvas texture with layered oil glaze and impasto paint strokes,
 * plus a matching bump map for physical bristle and linen relief.
 */
export function createLivingCanvasTexture(): THREE.CanvasTexture {
  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = 1024;
  albedoCanvas.height = 640;
  const ctx = albedoCanvas.getContext('2d')!;

  // Warm raw Belgian linen & gessoed ivory center
  ctx.fillStyle = '#E5DEC9';
  ctx.fillRect(0, 0, 1024, 640);

  const gessoGrad = ctx.createRadialGradient(512, 300, 50, 512, 320, 540);
  gessoGrad.addColorStop(0, '#F5F0E4');
  gessoGrad.addColorStop(1, '#E6DFCE');
  ctx.fillStyle = gessoGrad;
  ctx.fillRect(28, 28, 968, 584);

  // Fine woven linen thread cross-hatching
  ctx.strokeStyle = 'rgba(36, 30, 24, 0.045)';
  ctx.lineWidth = 1;
  for (let x = 0; x < 1024; x += 5) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 640);
    ctx.stroke();
  }
  for (let y = 0; y < 640; y += 5) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(1024, y);
    ctx.stroke();
  }

  // Subtle architectural golden-ratio under-drawing (charcoal & gold leaf)
  ctx.strokeStyle = 'rgba(201, 165, 106, 0.45)';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(48, 48, 928, 544);

  ctx.strokeStyle = 'rgba(28, 25, 23, 0.12)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(48, 424);
  ctx.lineTo(976, 424);
  ctx.moveTo(380, 48);
  ctx.lineTo(380, 424);
  ctx.moveTo(680, 48);
  ctx.lineTo(680, 424);
  ctx.stroke();

  // Atmospheric oil glaze wash behind the main stroke
  const washGrad = ctx.createRadialGradient(520, 250, 20, 520, 250, 340);
  washGrad.addColorStop(0, 'rgba(185, 160, 120, 0.2)');
  washGrad.addColorStop(0.55, 'rgba(107, 132, 196, 0.08)');
  washGrad.addColorStop(1, 'rgba(241, 238, 231, 0)');
  ctx.fillStyle = washGrad;
  ctx.beginPath();
  ctx.arc(520, 250, 340, 0, Math.PI * 2);
  ctx.fill();

  // Deep charcoal & slate underpainting stroke
  ctx.strokeStyle = '#171819';
  ctx.lineWidth = 72;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(135, 305);
  ctx.bezierCurveTo(330, 145, 610, 385, 885, 205);
  ctx.stroke();

  // Primary rich oil impasto stroke (Muted Slate Cobalt -> Terracotta -> Champagne -> Verdigris)
  const grad1 = ctx.createLinearGradient(120, 210, 900, 280);
  grad1.addColorStop(0, '#5B74B4');
  grad1.addColorStop(0.42, '#C7745C');
  grad1.addColorStop(0.76, '#B9A078');
  grad1.addColorStop(1, '#659B93');

  ctx.strokeStyle = grad1;
  ctx.lineWidth = 52;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(140, 295);
  ctx.bezierCurveTo(340, 155, 620, 380, 890, 215);
  ctx.stroke();

  // Fine bristle ridge highlights inside the impasto stroke
  ctx.strokeStyle = 'rgba(241, 238, 231, 0.42)';
  ctx.lineWidth = 2.5;
  for (let offset = -16; offset <= 16; offset += 8) {
    ctx.beginPath();
    ctx.moveTo(145, 295 + offset);
    ctx.bezierCurveTo(340, 155 + offset, 620, 380 + offset, 885, 215 + offset);
    ctx.stroke();
  }

  // Secondary champagne harmonic data spline
  ctx.strokeStyle = '#B9A078';
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.moveTo(160, 355);
  ctx.bezierCurveTo(395, 235, 615, 415, 875, 275);
  ctx.stroke();

  // Curated data nodes embedded as metallic leaf & oil pigment medallions
  const points = [
    [195, 265, '#F1EEE7', '#171819'],
    [315, 232, '#6B84C4', '#F1EEE7'],
    [455, 268, '#C7745C', '#F1EEE7'],
    [590, 304, '#B9A078', '#171819'],
    [735, 282, '#659B93', '#171819'],
    [850, 228, '#171819', '#B9A078'],
  ] as const;

  for (const [px, py, fillCol, ringCol] of points) {
    ctx.fillStyle = fillCol;
    ctx.beginPath();
    ctx.arc(px, py, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = ringCol;
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  // Museum exhibition plate inscription at base of linen canvas
  ctx.fillStyle = '#171819';
  ctx.font = '600 34px "Sora", -apple-system, sans-serif';
  ctx.fillText('Anirudh K N  —  The Data Atelier', 76, 488);

  ctx.fillStyle = 'rgba(23, 24, 25, 0.68)';
  ctx.font = '500 16px "Manrope", -apple-system, sans-serif';
  ctx.fillText('Data Science · Data Analytics · Machine Learning · Business Intelligence', 76, 528);

  const albedoMap = new THREE.CanvasTexture(albedoCanvas);
  albedoMap.colorSpace = THREE.SRGBColorSpace;
  return albedoMap;
}

/**
 * Generates a grayscale bump map matching the linen weave and thick impasto oil ridges.
 */
export function createCanvasBumpTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 320;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#787878';
  ctx.fillRect(0, 0, 512, 320);

  // Woven linen micro-grid
  ctx.strokeStyle = '#686868';
  ctx.lineWidth = 1;
  for (let x = 0; x < 512; x += 4) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 320);
    ctx.stroke();
  }
  for (let y = 0; y < 320; y += 4) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(512, y);
    ctx.stroke();
  }

  // High-relief impasto oil ridge
  ctx.strokeStyle = '#EFEFEF';
  ctx.lineWidth = 32;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(70, 148);
  ctx.bezierCurveTo(170, 78, 310, 190, 445, 108);
  ctx.stroke();

  const bump = new THREE.CanvasTexture(canvas);
  return bump;
}

/**
 * Generates a refined museum cartographic & tectonic Earth texture + topographic bump map for Seismos.
 */
export function createTectonicGlobeTexture(): THREE.CanvasTexture {
  const mapCanvas = document.createElement('canvas');
  mapCanvas.width = 1024;
  mapCanvas.height = 512;
  const mctx = mapCanvas.getContext('2d')!;

  // Deep obsidian bathymetrical ocean base
  const oceanGrad = mctx.createLinearGradient(0, 0, 0, 512);
  oceanGrad.addColorStop(0, '#0B0F17');
  oceanGrad.addColorStop(0.5, '#111824');
  oceanGrad.addColorStop(1, '#0B0F17');
  mctx.fillStyle = oceanGrad;
  mctx.fillRect(0, 0, 1024, 512);

  // Subtle brass cartographic graticule lines
  mctx.strokeStyle = 'rgba(201, 165, 106, 0.16)';
  mctx.lineWidth = 1;
  for (let x = 0; x <= 1024; x += 64) {
    mctx.beginPath();
    mctx.moveTo(x, 0);
    mctx.lineTo(x, 512);
    mctx.stroke();
  }
  for (let y = 0; y <= 512; y += 64) {
    mctx.beginPath();
    mctx.moveTo(0, y);
    mctx.lineTo(1024, y);
    mctx.stroke();
  }

  // Equator & Tropics in warm gold
  mctx.strokeStyle = 'rgba(201, 165, 106, 0.38)';
  mctx.lineWidth = 1.5;
  mctx.beginPath();
  mctx.moveTo(0, 256);
  mctx.lineTo(1024, 256);
  mctx.stroke();

  // Detailed multi-polygon continental silhouettes in warm dark bronze-stone (#252322) with gold coast outlines
  mctx.fillStyle = '#252322';
  mctx.strokeStyle = 'rgba(201, 165, 106, 0.62)';
  mctx.lineWidth = 2;

  const drawContinent = (pts: [number, number][]) => {
    mctx.beginPath();
    mctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) {
      mctx.lineTo(pts[i][0], pts[i][1]);
    }
    mctx.closePath();
    mctx.fill();
    mctx.stroke();
  };

  // North America
  drawContinent([
    [110, 95],
    [235, 85],
    [285, 145],
    [245, 215],
    [195, 235],
    [145, 185],
  ]);
  // South America
  drawContinent([
    [240, 255],
    [325, 275],
    [345, 345],
    [295, 435],
    [255, 395],
  ]);
  // Europe
  drawContinent([
    [455, 95],
    [565, 85],
    [585, 155],
    [515, 175],
    [450, 150],
  ]);
  // Africa
  drawContinent([
    [455, 190],
    [575, 195],
    [615, 275],
    [565, 395],
    [505, 375],
    [450, 265],
  ]);
  // Asia
  drawContinent([
    [585, 90],
    [835, 95],
    [875, 185],
    [795, 255],
    [695, 265],
    [615, 205],
  ]);
  // Australia
  drawContinent([
    [765, 320],
    [875, 315],
    [890, 385],
    [795, 405],
  ]);

  // Tectonic fault boundary lines (Circum-Pacific Ring of Fire & Alpide Belt)
  mctx.strokeStyle = 'rgba(255, 89, 62, 0.72)';
  mctx.lineWidth = 2.5;
  mctx.setLineDash([6, 4]);
  mctx.beginPath();
  mctx.moveTo(760, 390);
  mctx.bezierCurveTo(845, 250, 885, 130, 920, 105);
  mctx.moveTo(115, 120);
  mctx.bezierCurveTo(175, 220, 235, 290, 285, 425);
  mctx.moveTo(520, 175);
  mctx.bezierCurveTo(645, 195, 735, 225, 815, 285);
  mctx.stroke();
  mctx.setLineDash([]);

  const globeTex = new THREE.CanvasTexture(mapCanvas);
  globeTex.colorSpace = THREE.SRGBColorSpace;
  return globeTex;
}

/**
 * Generates an archival museum exhibition plate texture for the About space.
 */
export function createGalleryFrameTexture(
  kicker: string,
  headline: string,
  subline: string,
  accentColor: string,
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 640;
  const ctx = canvas.getContext('2d')!;

  // Warm museum conservation mat board (#171819)
  ctx.fillStyle = '#171819';
  ctx.fillRect(0, 0, 512, 640);

  // Inner archival paper mount (#1D1E20)
  ctx.fillStyle = '#1D1E20';
  ctx.fillRect(28, 28, 456, 584);

  // Subtle champagne & pigment bevel rule
  ctx.strokeStyle = 'rgba(185, 160, 120, 0.45)';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(28, 28, 456, 584);

  ctx.strokeStyle = accentColor;
  ctx.lineWidth = 1;
  ctx.strokeRect(40, 40, 432, 560);

  // Geometric curatorial plate engraving motif
  ctx.strokeStyle = 'rgba(241, 238, 231, 0.12)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(256, 225, 114, 0, Math.PI * 2);
  ctx.stroke();

  ctx.strokeStyle = accentColor;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(256, 225, 76, -Math.PI * 0.25, Math.PI * 0.85);
  ctx.stroke();

  const grad = ctx.createRadialGradient(256, 225, 10, 256, 225, 108);
  grad.addColorStop(0, accentColor);
  grad.addColorStop(1, 'rgba(29, 30, 32, 0)');
  ctx.fillStyle = grad;
  ctx.globalAlpha = 0.28;
  ctx.beginPath();
  ctx.arc(256, 225, 108, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;

  // Horizontal divider rule
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.09)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(56, 396);
  ctx.lineTo(456, 396);
  ctx.stroke();

  ctx.fillStyle = '#B9A078';
  ctx.font = '500 14px "IBM Plex Mono", monospace';
  ctx.fillText(kicker.toUpperCase(), 56, 436);

  ctx.fillStyle = '#F1EEE7';
  ctx.font = '600 30px "Sora", -apple-system, sans-serif';
  ctx.fillText(headline, 56, 484);

  ctx.fillStyle = '#A5A39D';
  ctx.font = '400 17px "Manrope", -apple-system, sans-serif';
  ctx.fillText(subline, 56, 524);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Generates a textured warm ivory linen signature canvas for Room 6 (Contact — The Final Signature).
 */
export function createSignatureCanvasTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  // Warm museum linen ivory
  ctx.fillStyle = '#EFE9DA';
  ctx.fillRect(0, 0, 1024, 512);

  // Subtle woven linen grain
  ctx.strokeStyle = 'rgba(34, 28, 22, 0.04)';
  ctx.lineWidth = 1;
  for (let x = 0; x < 1024; x += 6) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, 512);
    ctx.stroke();
  }
  for (let y = 0; y < 512; y += 6) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(1024, y);
    ctx.stroke();
  }

  // Blind-debossed archival border & champagne fillet
  ctx.strokeStyle = 'rgba(185, 160, 120, 0.55)';
  ctx.lineWidth = 2;
  ctx.strokeRect(36, 36, 952, 440);

  ctx.strokeStyle = 'rgba(23, 24, 25, 0.14)';
  ctx.lineWidth = 1;
  ctx.strokeRect(48, 48, 928, 416);

  // Subtle baseline rule for the signature
  ctx.strokeStyle = 'rgba(23, 24, 25, 0.16)';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(140, 330);
  ctx.lineTo(884, 330);
  ctx.stroke();

  // Curatorial colophon inscription
  ctx.fillStyle = 'rgba(23, 24, 25, 0.56)';
  ctx.font = '500 15px "IBM Plex Mono", monospace';
  ctx.fillText('EDITION I  ·  SIGNED BY THE CREATOR  ·  KERALA, INDIA', 140, 372);

  ctx.fillStyle = '#171819';
  ctx.font = '600 26px "Sora", -apple-system, sans-serif';
  ctx.fillText('Anirudh K N — Data Science, Analytics & AI/ML', 140, 416);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Loads Anirudh K N's transparent cutout portrait ('/assets/anirudh-profile-cutout.webp'),
 * preserves full subject authenticity and alpha channel, and strips tiny isolated background
 * matting speckles outside the main portrait silhouette so the museum mat board shows cleanly.
 */
export function loadCleanTransparentPortraitTexture(
  url: string,
  onLoad: (tex: THREE.Texture, aspectRatio: number) => void,
  onError?: () => void,
): void {
  if (typeof Image === 'undefined' || typeof document === 'undefined') {
    onError?.();
    return;
  }

  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.onload = () => {
    try {
      const w = img.naturalWidth || 1096;
      const h = img.naturalHeight || 1280;
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        const fallback = new THREE.TextureLoader().load(url);
        fallback.colorSpace = THREE.SRGBColorSpace;
        onLoad(fallback, w / h);
        return;
      }

      ctx.clearRect(0, 0, w, h);
      ctx.drawImage(img, 0, 0, w, h);

      // Clean isolated tiny alpha noise dots in the background while keeping the connected central portrait 100% intact.
      const imgData = ctx.getImageData(0, 0, w, h);
      const data = imgData.data;

      // Downsampled flood-fill / connected-component mask from the subject center (w/2, h*0.58)
      const scale = 4;
      const gw = Math.ceil(w / scale);
      const gh = Math.ceil(h / scale);
      const occupied = new Uint8Array(gw * gh);
      const visited = new Uint8Array(gw * gh);

      for (let gy = 0; gy < gh; gy++) {
        for (let gx = 0; gx < gw; gx++) {
          let maxA = 0;
          for (let dy = 0; dy < scale; dy++) {
            const py = Math.min(h - 1, gy * scale + dy);
            for (let dx = 0; dx < scale; dx++) {
              const px = Math.min(w - 1, gx * scale + dx);
              const a = data[(py * w + px) * 4 + 3];
              if (a > maxA) maxA = a;
            }
          }
          if (maxA > 32) {
            occupied[gy * gw + gx] = 1;
          }
        }
      }

      // BFS from the portrait torso/head core to mark the main connected subject silhouette
      const seedX = Math.floor(gw * 0.5);
      const seedY = Math.floor(gh * 0.55);
      const queue = new Int32Array(gw * gh);
      let head = 0;
      let tail = 0;
      const startIdx = seedY * gw + seedX;
      visited[startIdx] = 1;
      queue[tail++] = startIdx;

      while (head < tail) {
        const curr = queue[head++];
        const cx = curr % gw;
        const cy = (curr - cx) / gw;
        for (let ny = Math.max(0, cy - 2); ny <= Math.min(gh - 1, cy + 2); ny++) {
          for (let nx = Math.max(0, cx - 2); nx <= Math.min(gw - 1, cx + 2); nx++) {
            const nIdx = ny * gw + nx;
            if (!visited[nIdx] && occupied[nIdx]) {
              visited[nIdx] = 1;
              queue[tail++] = nIdx;
            }
          }
        }
      }

      // Zero out disconnected background noise pixels outside the main subject component
      for (let py = 0; py < h; py++) {
        const gy = Math.min(gh - 1, Math.floor(py / scale));
        for (let px = 0; px < w; px++) {
          const gx = Math.min(gw - 1, Math.floor(px / scale));
          const idx = (py * w + px) * 4;
          if (!visited[gy * gw + gx] || data[idx + 3] < 24) {
            data[idx + 3] = 0;
          }
        }
      }

      ctx.putImageData(imgData, 0, 0);

      const tex = new THREE.CanvasTexture(canvas);
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.needsUpdate = true;
      onLoad(tex, w / h);
    } catch {
      const fallback = new THREE.TextureLoader().load(url);
      fallback.colorSpace = THREE.SRGBColorSpace;
      onLoad(fallback, 1096 / 1280);
    }
  };
  img.onerror = () => {
    onError?.();
  };
  img.src = url;
}

/**
 * Detects whether the current browser environment supports WebGL rendering.
 * Also supports ?webgl=fallback query parameter for deterministic fallback testing.
 */
export function checkWebGLSupport(): { supported: boolean; reason?: string } {
  if (typeof window === 'undefined' || typeof document === 'undefined') {
    return { supported: true };
  }

  try {
    const params = new URLSearchParams(window.location.search);
    if (params.get('webgl') === 'fallback' || params.get('webgl') === '0') {
      return {
        supported: false,
        reason: 'Non-3D museum edition requested via URL parameter.',
      };
    }

    if (!window.WebGLRenderingContext) {
      return {
        supported: false,
        reason: 'WebGLRenderingContext is not available in this browser.',
      };
    }

    const canvas = document.createElement('canvas');
    const gl =
      canvas.getContext('webgl2') ||
      canvas.getContext('webgl') ||
      canvas.getContext('experimental-webgl');

    if (!gl) {
      return {
        supported: false,
        reason: 'Unable to initialize a WebGL2 or WebGL1 rendering context.',
      };
    }

    return { supported: true };
  } catch {
    return {
      supported: false,
      reason: 'An exception occurred while probing WebGL support.',
    };
  }
}


