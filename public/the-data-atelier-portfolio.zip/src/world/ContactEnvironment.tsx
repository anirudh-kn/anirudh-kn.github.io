import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { SPATIAL_DESTINATIONS } from '../data/portfolioData';
import {
  createCanvasBumpTexture,
  createSignatureCanvasTexture,
  createWalnutWoodTexture,
} from '../three/studioEngine';

export const ContactEnvironment: React.FC = () => {
  const contactCenter = SPATIAL_DESTINATIONS[5].roomCenter;
  const brushRef = useRef<THREE.Group | null>(null);
  const canvasPlinthRef = useRef<THREE.Group | null>(null);

  const signatureCanvasTex = useMemo(() => createSignatureCanvasTexture(), []);
  const canvasBumpMap = useMemo(() => createCanvasBumpTexture(), []);
  const walnutMap = useMemo(() => createWalnutWoodTexture(), []);

  // 3D Calligraphic Signature Stroke Painted Onto the Tilted Ivory Linen Canvas
  const { signatureCurve, signatureTubeGeo, goldAccentGeo } = useMemo(() => {
    const pts = [
      new THREE.Vector3(-2.15, -0.18, 0.08),
      new THREE.Vector3(-1.45, 0.48, 0.11),
      new THREE.Vector3(-0.85, -0.14, 0.085),
      new THREE.Vector3(-0.22, 0.34, 0.105),
      new THREE.Vector3(0.38, -0.12, 0.085),
      new THREE.Vector3(1.05, 0.42, 0.11),
      new THREE.Vector3(1.65, -0.15, 0.085),
      new THREE.Vector3(2.22, 0.28, 0.1),
    ];
    const goldPts = pts.map(
      (p) => new THREE.Vector3(p.x + 0.04, p.y - 0.09, p.z - 0.01),
    );
    const curve = new THREE.CatmullRomCurve3(pts);
    const goldCurve = new THREE.CatmullRomCurve3(goldPts);
    const mainGeo = new THREE.TubeGeometry(curve, 96, 0.052, 16, false);
    const subGeo = new THREE.TubeGeometry(goldCurve, 84, 0.022, 12, false);
    return { signatureCurve: curve, signatureTubeGeo: mainGeo, goldAccentGeo: subGeo };
  }, []);

  // Lathe-Turned Walnut Brush Handle & Sculpted Hog-Bristle Heel
  const { handleLatheGeo, bristleHeelGeo } = useMemo(() => {
    const handlePts = [
      new THREE.Vector2(0.012, 0.25),
      new THREE.Vector2(0.048, 0.65),
      new THREE.Vector2(0.068, 1.15),
      new THREE.Vector2(0.052, 1.55),
      new THREE.Vector2(0.016, 1.85),
    ];
    const bristlePts = [
      new THREE.Vector2(0.008, -0.45),
      new THREE.Vector2(0.032, -0.32),
      new THREE.Vector2(0.056, -0.15),
      new THREE.Vector2(0.058, 0.0),
    ];
    return {
      handleLatheGeo: new THREE.LatheGeometry(handlePts, 24),
      bristleHeelGeo: new THREE.LatheGeometry(bristlePts, 20),
    };
  }, []);

  useFrame(({ clock }) => {
    const elapsed = clock.getElapsedTime();
    if (brushRef.current) {
      const t = (Math.sin(elapsed * 0.52) + 1) * 0.5;
      const pt = signatureCurve.getPointAt(t);
      brushRef.current.position.set(pt.x, pt.y + 0.36, pt.z + 0.28);
      brushRef.current.rotation.z = 0.52 + Math.cos(elapsed * 1.04) * 0.14;
      brushRef.current.rotation.x = 0.38 + Math.sin(elapsed * 0.8) * 0.06;
    }
  });

  return (
    <group position={contactCenter} name="contact-final-signature">
      {/* 1. Tilted Textured Warm Ivory Linen Signature Canvas & Walnut Frame */}
      <group
        ref={canvasPlinthRef}
        position={[0.35, 0.36, -0.35]}
        rotation={[-0.22, -0.06, 0]}
      >
        {/* Stretched Warm Ivory Linen Canvas Backing with Woven Bump Relief */}
        <mesh>
          <boxGeometry args={[5.4, 2.7, 0.12]} />
          <meshStandardMaterial
            color="#E8DFCE"
            bumpMap={canvasBumpMap}
            bumpScale={0.025}
            roughness={0.68}
            metalness={0.04}
          />
        </mesh>
        {/* Front Illuminated Warm Ivory Linen Signature Surface */}
        <mesh position={[0, 0, 0.068]}>
          <planeGeometry args={[5.34, 2.64]} />
          <meshStandardMaterial
            color="#FFFFFF"
            map={signatureCanvasTex}
            emissive="#FFF8EC"
            emissiveMap={signatureCanvasTex}
            emissiveIntensity={0.42}
            bumpMap={canvasBumpMap}
            bumpScale={0.022}
            roughness={0.58}
            metalness={0.04}
          />
        </mesh>

        {/* Outer Dark American Walnut Frame */}
        <mesh position={[0, 1.4, 0.01]}>
          <boxGeometry args={[5.66, 0.13, 0.2]} />
          <meshStandardMaterial
            color="#FFFFFF"
            map={walnutMap}
            roughness={0.36}
            metalness={0.18}
          />
        </mesh>
        <mesh position={[0, -1.4, 0.01]}>
          <boxGeometry args={[5.66, 0.13, 0.2]} />
          <meshStandardMaterial
            color="#FFFFFF"
            map={walnutMap}
            roughness={0.36}
            metalness={0.18}
          />
        </mesh>
        <mesh position={[-2.76, 0, 0.01]}>
          <boxGeometry args={[0.13, 2.92, 0.2]} />
          <meshStandardMaterial
            color="#FFFFFF"
            map={walnutMap}
            roughness={0.36}
            metalness={0.18}
          />
        </mesh>
        <mesh position={[2.76, 0, 0.01]}>
          <boxGeometry args={[0.13, 2.92, 0.2]} />
          <meshStandardMaterial
            color="#FFFFFF"
            map={walnutMap}
            roughness={0.36}
            metalness={0.18}
          />
        </mesh>

        {/* Inner Brushed Champagne Brass Fillet */}
        <mesh position={[0, 0, -0.01]}>
          <boxGeometry args={[5.48, 2.78, 0.14]} />
          <meshStandardMaterial color="#B9A078" roughness={0.22} metalness={0.9} />
        </mesh>

        {/* 2. Dimensional Wet-Oil Calligraphic Signature Stroke Onto the Canvas */}
        <mesh geometry={signatureTubeGeo}>
          <meshStandardMaterial
            color="#FF593E"
            emissive="#FF593E"
            emissiveIntensity={0.16}
            roughness={0.14}
            metalness={0.12}
          />
        </mesh>
        <mesh geometry={goldAccentGeo}>
          <meshStandardMaterial
            color="#C9A56A"
            roughness={0.18}
            metalness={0.92}
          />
        </mesh>

        {/* 3. Sculpted Multi-Part Artist's Paintbrush Tracing the Signature */}
        <group ref={brushRef} rotation={[0.38, -0.28, 0.55]}>
          {/* Lathe-Turned Walnut Handle */}
          <mesh geometry={handleLatheGeo}>
            <meshStandardMaterial
              color="#FFFFFF"
              map={walnutMap}
              roughness={0.32}
              metalness={0.12}
            />
          </mesh>
          {/* Double-Crimped Brushed Brass Ferrule */}
          <mesh position={[0, 0.12, 0]}>
            <cylinderGeometry args={[0.056, 0.058, 0.28, 24]} />
            <meshStandardMaterial color="#C9A56A" roughness={0.18} metalness={0.94} />
          </mesh>
          <mesh position={[0, 0.02, 0]} rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[0.059, 0.006, 10, 24]} />
            <meshStandardMaterial color="#E5CA96" roughness={0.16} metalness={0.95} />
          </mesh>
          {/* Sculpted Natural Bristle Heel */}
          <mesh geometry={bristleHeelGeo}>
            <meshStandardMaterial
              color="#3D2E22"
              bumpMap={canvasBumpMap}
              bumpScale={0.015}
              roughness={0.8}
              metalness={0.05}
            />
          </mesh>
          {/* Wet Vermilion Oil Tip Contacting the Canvas */}
          <mesh position={[0, -0.38, 0]} rotation={[Math.PI, 0, 0]}>
            <coneGeometry args={[0.036, 0.22, 18]} />
            <meshStandardMaterial
              color="#FF593E"
              emissive="#FF593E"
              emissiveIntensity={0.22}
              roughness={0.12}
              metalness={0.15}
            />
          </mesh>
        </group>
      </group>

      {/* 4. Architectural Honed Stone & Brass Presentation Plinth Supporting the Signature */}
      <group position={[0.15, -1.75, -0.35]}>
        <mesh position={[0, -0.18, 0]}>
          <cylinderGeometry args={[3.1, 3.35, 0.48, 48]} />
          <meshStandardMaterial color="#141317" roughness={0.44} metalness={0.22} />
        </mesh>
        <mesh position={[0, 0.08, 0]}>
          <cylinderGeometry args={[2.75, 2.9, 0.08, 48]} />
          <meshStandardMaterial color="#1C1A1F" roughness={0.38} metalness={0.28} />
        </mesh>
        <mesh position={[0, 0.13, 0]} rotation={[Math.PI / 2, 0, 0]}>
          <torusGeometry args={[2.75, 0.022, 14, 64]} />
          <meshStandardMaterial color="#C9A56A" roughness={0.22} metalness={0.9} />
        </mesh>
      </group>
    </group>
  );
};
