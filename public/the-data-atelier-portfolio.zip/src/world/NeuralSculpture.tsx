import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { SKILL_CATEGORIES, SPATIAL_DESTINATIONS } from '../data/portfolioData';

interface NeuralSculptureProps {
  activeCategoryId: string;
  onSelectCategory: (categoryId: string) => void;
}

export const NeuralSculpture: React.FC<NeuralSculptureProps> = ({
  activeCategoryId,
  onSelectCategory,
}) => {
  const skillsCenter = SPATIAL_DESTINATIONS[2].roomCenter;
  const networkGroupRef = useRef<THREE.Group | null>(null);
  const coreGroupRef = useRef<THREE.Group | null>(null);
  const categoryRefs = useRef<Record<string, THREE.Group | null>>({});

  // Precompute organic curved 3D glass & brushed brass tubular pathways (replaces straight primitive lines)
  const { glassPathways, brassFilaments } = useMemo(() => {
    const glassTubes: { id: string; geo: THREE.TubeGeometry; color: string }[] = [];
    const brassTubes: THREE.TubeGeometry[] = [];
    const positions = SKILL_CATEGORIES.map((c) => new THREE.Vector3(...c.nodePosition));

    SKILL_CATEGORIES.forEach((cat, idx) => {
      const pos = positions[idx];
      // Organic arched midpoint between central hub and category vessel
      const mid1 = pos
        .clone()
        .multiplyScalar(0.48)
        .add(
          new THREE.Vector3(
            0,
            (idx % 2 === 0 ? 1 : -1) * 0.45,
            (idx % 3 === 0 ? 1 : -1) * 0.35,
          ),
        );
      const hubCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(0, 0, 0),
        mid1,
        pos,
      ]);
      glassTubes.push({
        id: cat.id,
        geo: new THREE.TubeGeometry(hubCurve, 36, 0.024, 10, false),
        color: cat.color,
      });

      // Curved cross-category filament to next node and opposite harmonic node
      const nextPos = positions[(idx + 1) % positions.length];
      const crossMid = pos
        .clone()
        .add(nextPos)
        .multiplyScalar(0.5)
        .multiplyScalar(1.18);
      const crossCurve = new THREE.CatmullRomCurve3([pos, crossMid, nextPos]);
      brassTubes.push(new THREE.TubeGeometry(crossCurve, 32, 0.012, 8, false));
    });

    return { glassPathways: glassTubes, brassFilaments: brassTubes };
  }, []);

  useFrame(({ clock }, delta) => {
    const elapsed = clock.getElapsedTime();
    if (networkGroupRef.current) {
      networkGroupRef.current.rotation.y = Math.sin(elapsed * 0.22) * 0.24;
      networkGroupRef.current.rotation.x = Math.cos(elapsed * 0.18) * 0.05;
    }
    if (coreGroupRef.current) {
      coreGroupRef.current.rotation.y = elapsed * 0.25;
      coreGroupRef.current.rotation.z = Math.sin(elapsed * 0.3) * 0.15;
    }

    for (const cat of SKILL_CATEGORIES) {
      const grp = categoryRefs.current[cat.id];
      if (!grp) continue;
      const isSelected = activeCategoryId === cat.id;
      const targetScale = isSelected ? 1.28 : 1.0;
      const nextScale = THREE.MathUtils.damp(grp.scale.x, targetScale, 6, delta);
      grp.scale.setScalar(nextScale);
    }
  });

  return (
    <group position={skillsCenter} name="skills-neural-sculpture">
      {/* 1. Architectural Museum Pedestal Anchoring the Neural Sculpture */}
      <group position={[0, -2.25, 0]}>
        <mesh position={[0, -0.35, 0]}>
          <cylinderGeometry args={[1.85, 2.05, 0.55, 48]} />
          <meshStandardMaterial color="#151418" roughness={0.48} metalness={0.2} />
        </mesh>
        <mesh position={[0, -0.05, 0]}>
          <cylinderGeometry args={[1.45, 1.65, 0.12, 48]} />
          <meshStandardMaterial color="#1E1C21" roughness={0.42} metalness={0.25} />
        </mesh>
        <mesh position={[0, 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[1.38, 1.44, 48]} />
          <meshStandardMaterial
            color="#B9A078"
            roughness={0.22}
            metalness={0.9}
            side={THREE.DoubleSide}
          />
        </mesh>
        {/* Central Brass Suspension Column */}
        <mesh position={[0, 1.15, 0]}>
          <cylinderGeometry args={[0.045, 0.065, 2.3, 20]} />
          <meshStandardMaterial color="#B9A078" roughness={0.24} metalness={0.88} />
        </mesh>
      </group>

      {/* 2. Organic Handcrafted Neural Sculpture Assembly */}
      <group ref={networkGroupRef} position={[0, 0.25, 0]}>
        {/* Central Core Astrolabe & Translucent Glass Nucleus */}
        <group ref={coreGroupRef}>
          <mesh>
            <icosahedronGeometry args={[0.36, 0]} />
            <meshStandardMaterial color="#B9A078" roughness={0.18} metalness={0.92} />
          </mesh>
          <mesh>
            <dodecahedronGeometry args={[0.56, 1]} />
            <meshStandardMaterial
              color="#F1EEE7"
              transparent
              opacity={0.32}
              roughness={0.15}
              metalness={0.1}
              depthWrite={false}
            />
          </mesh>
          <mesh rotation={[0.4, 0.2, 0]}>
            <torusGeometry args={[0.74, 0.016, 14, 48]} />
            <meshStandardMaterial color="#B9A078" roughness={0.22} metalness={0.9} />
          </mesh>
          <mesh rotation={[-0.5, 0.8, 0.4]}>
            <torusGeometry args={[0.84, 0.012, 14, 48]} />
            <meshStandardMaterial color="#8A724C" roughness={0.28} metalness={0.85} />
          </mesh>
        </group>

        {/* Curved Glass Pathways Connecting Core to the 6 Category Vessels */}
        {glassPathways.map((item) => {
          const isSelected = activeCategoryId === item.id;
          return (
            <mesh key={`glass-path-${item.id}`} geometry={item.geo}>
              <meshStandardMaterial
                color={isSelected ? item.color : '#F1EEE7'}
                emissive={item.color}
                emissiveIntensity={isSelected ? 0.35 : 0.06}
                transparent
                opacity={isSelected ? 0.88 : 0.48}
                roughness={0.15}
                metalness={0.15}
              />
            </mesh>
          );
        })}

        {/* Delicate Curved Brushed Brass Cross-Filaments */}
        {brassFilaments.map((geo, idx) => (
          <mesh key={`brass-filament-${idx}`} geometry={geo}>
            <meshStandardMaterial
              color="#B9A078"
              roughness={0.26}
              metalness={0.88}
            />
          </mesh>
        ))}

        {/* Six Clickable Multi-Part Category Vessels + Satellite Skill Nodes */}
        {SKILL_CATEGORIES.map((cat, cIdx) => {
          const isSelected = activeCategoryId === cat.id;
          return (
            <group
              key={cat.id}
              position={cat.nodePosition}
              ref={(el) => {
                categoryRefs.current[cat.id] = el;
              }}
            >
              <group
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectCategory(cat.id);
                }}
                onPointerOver={(e) => {
                  e.stopPropagation();
                  document.body.style.cursor = 'pointer';
                }}
                onPointerOut={(e) => {
                  e.stopPropagation();
                  document.body.style.cursor = 'auto';
                }}
              >
                <mesh rotation={[cIdx * 0.4, cIdx * 0.6, 0]}>
                  {cIdx % 2 === 0 ? (
                    <octahedronGeometry args={[0.24, 0]} />
                  ) : (
                    <icosahedronGeometry args={[0.24, 0]} />
                  )}
                  <meshStandardMaterial
                    color={cat.color}
                    emissive={cat.color}
                    emissiveIntensity={isSelected ? 0.42 : 0.14}
                    roughness={0.18}
                    metalness={0.28}
                  />
                </mesh>

                <mesh>
                  <sphereGeometry args={[0.36, 20, 20]} />
                  <meshStandardMaterial
                    color="#F1EBDD"
                    transparent
                    opacity={isSelected ? 0.4 : 0.24}
                    roughness={0.12}
                    metalness={0.1}
                    depthWrite={false}
                  />
                </mesh>

                <mesh rotation={[Math.PI / 3, Math.PI / 5, 0]}>
                  <torusGeometry args={[0.48, 0.016, 12, 42]} />
                  <meshStandardMaterial
                    color={isSelected ? '#C9A56A' : '#8A724C'}
                    roughness={0.22}
                    metalness={0.9}
                  />
                </mesh>
                <mesh rotation={[-Math.PI / 4, 0, Math.PI / 3]}>
                  <torusGeometry args={[0.54, 0.01, 10, 36]} />
                  <meshStandardMaterial color="#C9A56A" roughness={0.24} metalness={0.88} />
                </mesh>
              </group>

              {cat.skills.map((skill, sIdx) => {
                const angle = (sIdx / cat.skills.length) * Math.PI * 2 + cIdx * 0.3;
                const radius = 0.72 + (sIdx % 2) * 0.12;
                const sx = Math.cos(angle) * radius;
                const sy = Math.sin(angle) * radius;
                const sz = (sIdx % 2 === 0 ? 1 : -1) * 0.18;
                const nodeRadius = 0.075 + (sIdx % 3) * 0.022;

                return (
                  <group key={skill.name} position={[sx, sy, sz]}>
                    <mesh>
                      <sphereGeometry args={[nodeRadius, 14, 14]} />
                      <meshStandardMaterial
                        color={sIdx % 2 === 0 ? '#F1EBDD' : cat.color}
                        roughness={0.22}
                        metalness={sIdx % 2 === 0 ? 0.15 : 0.45}
                      />
                    </mesh>
                    <mesh rotation={[angle, 0, 0]}>
                      <torusGeometry args={[nodeRadius * 1.35, 0.006, 8, 20]} />
                      <meshStandardMaterial color="#C9A56A" roughness={0.24} metalness={0.9} />
                    </mesh>
                  </group>
                );
              })}
            </group>
          );
        })}
      </group>
    </group>
  );
};
