import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { SPATIAL_DESTINATIONS, TIMELINE_ENTRIES } from '../data/portfolioData';

interface ExperienceTimelineProps {
  selectedEntryId: string;
  onSelectEntry: (entryId: string) => void;
}

export const ExperienceTimeline: React.FC<ExperienceTimelineProps> = ({
  selectedEntryId,
  onSelectEntry,
}) => {
  const expCenter = SPATIAL_DESTINATIONS[4].roomCenter;
  const ribbonGroupRef = useRef<THREE.Group | null>(null);

  const {
    mainRibbonGeo,
    upperRailGeo,
    lowerHarmonicGeo,
    milestonePositions,
  } = useMemo(() => {
    const curvePoints = [
      new THREE.Vector3(-4.5, -0.25, 0.35),
      new THREE.Vector3(-2.6, 0.78, -0.25),
      new THREE.Vector3(-0.75, -0.38, 0.32),
      new THREE.Vector3(1.1, 0.72, -0.22),
      new THREE.Vector3(2.85, -0.28, 0.28),
      new THREE.Vector3(4.5, 0.52, -0.18),
    ];
    const upperPoints = curvePoints.map(
      (p, i) =>
        new THREE.Vector3(
          p.x,
          p.y + 0.16,
          p.z + (i % 2 === 0 ? 0.08 : -0.08),
        ),
    );
    const lowerPoints = curvePoints.map(
      (p, i) =>
        new THREE.Vector3(
          p.x,
          p.y - 0.18,
          p.z + (i % 2 === 0 ? -0.1 : 0.1),
        ),
    );

    const mainCurve = new THREE.CatmullRomCurve3(curvePoints);
    const upperCurve = new THREE.CatmullRomCurve3(upperPoints);
    const lowerCurve = new THREE.CatmullRomCurve3(lowerPoints);

    const mainTube = new THREE.TubeGeometry(mainCurve, 96, 0.085, 18, false);
    const upperTube = new THREE.TubeGeometry(upperCurve, 84, 0.028, 12, false);
    const lowerTube = new THREE.TubeGeometry(lowerCurve, 84, 0.032, 12, false);

    const nodes = TIMELINE_ENTRIES.map((entry, idx) => {
      const t = (idx + 0.5) / TIMELINE_ENTRIES.length;
      const pt = mainCurve.getPointAt(t);
      return {
        entry,
        index: idx,
        pos: [pt.x, pt.y, pt.z] as [number, number, number],
      };
    });

    return {
      mainRibbonGeo: mainTube,
      upperRailGeo: upperTube,
      lowerHarmonicGeo: lowerTube,
      milestonePositions: nodes,
    };
  }, []);

  useFrame(({ clock }) => {
    const elapsed = clock.getElapsedTime();
    if (ribbonGroupRef.current) {
      ribbonGroupRef.current.position.y = 0.35 + Math.sin(elapsed * 0.45) * 0.04;
    }
  });

  return (
    <group position={expCenter} name="experience-creative-timeline">
      {/* Architectural Stone Gallery Plinth Spanning the Timeline Base */}
      <group position={[0, -2.12, 0]}>
        <mesh>
          <boxGeometry args={[10.4, 0.22, 1.85]} />
          <meshStandardMaterial color="#151418" roughness={0.48} metalness={0.2} />
        </mesh>
        <mesh position={[0, 0.12, 0]}>
          <boxGeometry args={[10.1, 0.03, 1.62]} />
          <meshStandardMaterial color="#B9A078" roughness={0.24} metalness={0.9} />
        </mesh>
      </group>

      {/* Multi-Strand Flowing Sculptural Ribbon & Engraved Metallic Milestones */}
      <group ref={ribbonGroupRef}>
        {/* 1. Primary Sculpted Champagne Bronze Ribbon */}
        <mesh geometry={mainRibbonGeo}>
          <meshStandardMaterial
            color="#B9A078"
            roughness={0.2}
            metalness={0.92}
          />
        </mesh>

        {/* 2. Upper Warm Ivory Ceramic Strand */}
        <mesh geometry={upperRailGeo}>
          <meshStandardMaterial
            color="#F1EEE7"
            roughness={0.18}
            metalness={0.1}
          />
        </mesh>

        {/* 3. Lower Verdigris Teal & Aged Bronze Harmonic Filament */}
        <mesh geometry={lowerHarmonicGeo}>
          <meshStandardMaterial
            color="#54B7AB"
            roughness={0.26}
            metalness={0.68}
          />
        </mesh>

        {/* 4. Twelve Engraved Metallic Milestone Medallions & Display Plaques */}
        {milestonePositions.map(({ entry, index, pos }) => {
          const isSelected = entry.id === selectedEntryId;
          const stanchionHeight = Math.max(0.4, pos[1] + 2.15);

          return (
            <group key={entry.id} position={pos}>
              {/* Vertical Brushed Brass Stanchion Anchoring Medallion to the Plinth */}
              <mesh position={[0, -stanchionHeight / 2, -0.06]}>
                <cylinderGeometry args={[0.012, 0.016, stanchionHeight, 12]} />
                <meshStandardMaterial color="#8A724C" roughness={0.3} metalness={0.85} />
              </mesh>

              {/* Clickable Engraved Metallic Medallion Assembly */}
              <group
                scale={isSelected ? 1.38 : 1.0}
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectEntry(entry.id);
                }}
                onPointerOver={(e) => {
                  e.stopPropagation();
                  document.body.style.cursor = 'pointer';
                }}
                onPointerOut={(e) => {
                  e.stopPropagation();
                  document.body.style.cursor = 'auto';
                }}
              >
                {/* Outer Brushed Champagne Brass Medallion Bezel */}
                <mesh rotation={[Math.PI / 2, 0, 0]}>
                  <cylinderGeometry args={[0.24, 0.24, 0.055, 28]} />
                  <meshStandardMaterial
                    color={isSelected ? '#F1EEE7' : '#B9A078'}
                    roughness={0.2}
                    metalness={0.92}
                  />
                </mesh>

                {/* Recessed Dark Stone Medallion Face */}
                <mesh position={[0, 0, 0.025]} rotation={[Math.PI / 2, 0, 0]}>
                  <cylinderGeometry args={[0.19, 0.19, 0.02, 24]} />
                  <meshStandardMaterial color="#141317" roughness={0.45} metalness={0.25} />
                </mesh>

                {/* Central Faceted Pigment Jewel */}
                <mesh position={[0, 0, 0.045]}>
                  <octahedronGeometry args={[0.11, 0]} />
                  <meshStandardMaterial
                    color={entry.pigmentColor}
                    emissive={entry.pigmentColor}
                    emissiveIntensity={isSelected ? 0.55 : 0.2}
                    roughness={0.16}
                    metalness={0.28}
                  />
                </mesh>

                {/* Outer Active Selection Halo Ring */}
                {isSelected && (
                  <mesh rotation={[0, 0, 0]}>
                    <torusGeometry args={[0.34, 0.014, 12, 36]} />
                    <meshStandardMaterial color="#C9A56A" roughness={0.18} metalness={0.95} />
                  </mesh>
                )}
              </group>

              {/* Museum Display Plaque Tablet Alternating Above/Below Medallion */}
              <group
                position={[0, index % 2 === 0 ? -0.44 : 0.44, 0.08]}
                rotation={[-0.22, 0, 0]}
              >
                <mesh>
                  <boxGeometry args={[0.48, 0.24, 0.025]} />
                  <meshStandardMaterial color="#18171C" roughness={0.42} metalness={0.3} />
                </mesh>
                <mesh position={[0, 0, 0.014]}>
                  <planeGeometry args={[0.42, 0.18]} />
                  <meshBasicMaterial color={isSelected ? '#C9A56A' : '#2A2725'} />
                </mesh>
              </group>
            </group>
          );
        })}
      </group>
    </group>
  );
};
