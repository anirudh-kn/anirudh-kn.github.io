import test from 'node:test';
import assert from 'node:assert/strict';
import {
  computeAspectPreservedDimensions,
  computeDevicePerformanceProfile,
  computeResponsiveCameraFrame,
  filterProjects,
  filterTimelineEntries,
  getDestinationByScrollProgress,
  getDestinationWaypoint,
  getFlightDurationSeconds,
  getProjectExecutiveBreakdown,
  interpolateSpatialCamera,
  isValidVerifiedUrl,
  latLonToCartesian,
  verifyPortfolioIntegrity,
} from './atelierLogic';
import {
  PROFILE_DATA,
  PROJECT_INSTALLATIONS,
  QUICK_PROFILE_SKILL_GROUPS,
  SPATIAL_DESTINATIONS,
  TIMELINE_ENTRIES,
} from '../data/portfolioData';

test('verifyPortfolioIntegrity confirms 6 spatial destinations, 4 verified projects, 7 real screenshots, 5 Quick Profile skill groups, and zero excluded projects', () => {
  const status = verifyPortfolioIntegrity();
  assert.equal(status.valid, true);
  assert.equal(status.destinationCount, 6);
  assert.equal(status.skillCategoryCount, 6);
  assert.equal(status.projectCount, 4);
  assert.equal(status.totalProjectScreenshots, 7);
  assert.equal(status.internshipCount, 3);
  assert.equal(status.quickProfileSkillGroupCount, 5);
  assert.equal(status.hasExcludedProjects, false);
  assert.equal(QUICK_PROFILE_SKILL_GROUPS.length, 5);
});

test('all profile, portrait, project screenshot, GitHub, and credential URLs are authentic and non-placeholder', () => {
  assert.equal(
    PROFILE_DATA.portraitImageUrl,
    '/assets/anirudh-profile-cutout.webp',
  );
  assert.equal(isValidVerifiedUrl(PROFILE_DATA.portraitImageUrl), true);
  assert.equal(isValidVerifiedUrl(PROFILE_DATA.githubUrl), true);
  assert.equal(isValidVerifiedUrl(PROFILE_DATA.linkedinUrl), true);
  assert.equal(isValidVerifiedUrl(PROFILE_DATA.emailHref), true);
  assert.equal(isValidVerifiedUrl(PROFILE_DATA.resumePdfUrl), true);
  assert.equal(isValidVerifiedUrl('#'), false);
  assert.equal(isValidVerifiedUrl('https://example.com/demo'), false);

  for (const project of PROJECT_INSTALLATIONS) {
    assert.equal(
      isValidVerifiedUrl(project.githubUrl),
      true,
      `Invalid GitHub URL for ${project.id}`,
    );
    assert.equal(
      project.screenshots.length > 0,
      true,
      `Missing screenshots for ${project.id}`,
    );
    for (const shot of project.screenshots) {
      assert.equal(
        isValidVerifiedUrl(shot.url),
        true,
        `Invalid screenshot URL ${shot.url} for ${project.id}`,
      );
      assert.equal(
        shot.url.startsWith('/assets/projects/'),
        true,
        `Screenshot ${shot.url} must live in /assets/projects/`,
      );
      assert.equal(shot.aspectRatio > 1.2, true);
    }
  }

  for (const entry of TIMELINE_ENTRIES) {
    if (entry.credentialUrl) {
      assert.equal(
        isValidVerifiedUrl(entry.credentialUrl),
        true,
        `Invalid credential URL for ${entry.id}`,
      );
    }
  }
});

test('computeAspectPreservedDimensions preserves original screenshot aspect ratios without stretching', () => {
  const salesRatio = 1378 / 777;
  const dims = computeAspectPreservedDimensions(salesRatio, 2.4, 1.8);
  assert.equal(Math.abs(dims.aspectRatio - salesRatio) < 0.002, true);
  assert.equal(dims.width <= 2.4, true);
  assert.equal(dims.height <= 1.8, true);

  const seismosWideRatio = 1917 / 900;
  const wideDims = computeAspectPreservedDimensions(seismosWideRatio, 2.6, 1.5);
  assert.equal(Math.abs(wideDims.aspectRatio - seismosWideRatio) < 0.002, true);
});

test('interpolateSpatialCamera and getDestinationByScrollProgress map all 6 rooms accurately', () => {
  assert.equal(getDestinationByScrollProgress(0), 'home');
  assert.equal(getDestinationByScrollProgress(0.2), 'about');
  assert.equal(getDestinationByScrollProgress(0.4), 'skills');
  assert.equal(getDestinationByScrollProgress(0.6), 'projects');
  assert.equal(getDestinationByScrollProgress(0.8), 'experience');
  assert.equal(getDestinationByScrollProgress(1.0), 'contact');

  const homeCam = interpolateSpatialCamera(0);
  assert.deepEqual(homeCam.cameraPos, SPATIAL_DESTINATIONS[0].cameraPos);
  assert.equal(homeCam.activeDestination, 'home');

  const contactCam = interpolateSpatialCamera(1);
  assert.deepEqual(contactCam.cameraPos, SPATIAL_DESTINATIONS[5].cameraPos);
  assert.equal(contactCam.activeDestination, 'contact');

  const projectsWp = getDestinationWaypoint('projects');
  assert.equal(projectsWp.roomTitle, 'THE DIGITAL EXHIBITION');
});

test('computeResponsiveCameraFrame adapts FOV and camera distance for mobile portrait (360x800, 390x844) vs desktop (1440x900) and accounts for expanded/collapsed panel states', () => {
  const home = SPATIAL_DESTINATIONS[0];
  const desktopExpandedFrame = computeResponsiveCameraFrame(
    home.cameraPos,
    home.cameraTarget,
    1440,
    900,
    true,
    false,
  );
  assert.equal(desktopExpandedFrame.isMobilePortrait, false);
  assert.equal(desktopExpandedFrame.fov, 44);
  assert.equal(desktopExpandedFrame.cameraPos[2], home.cameraPos[2]);
  assert.equal(desktopExpandedFrame.cameraTarget[0] < home.cameraTarget[0], true);

  const desktopCollapsedFrame = computeResponsiveCameraFrame(
    home.cameraPos,
    home.cameraTarget,
    1440,
    900,
    false,
    false,
  );
  assert.equal(desktopCollapsedFrame.cameraPos[0], home.cameraPos[0]);
  assert.equal(desktopCollapsedFrame.cameraTarget[0], home.cameraTarget[0]);

  const seismos = PROJECT_INSTALLATIONS[0];
  const projectExpandedDesktop = computeResponsiveCameraFrame(
    seismos.zoomCameraPos,
    seismos.zoomCameraTarget,
    1440,
    900,
    true,
    true,
  );
  const projectCollapsedDesktop = computeResponsiveCameraFrame(
    seismos.zoomCameraPos,
    seismos.zoomCameraTarget,
    1440,
    900,
    false,
    true,
  );
  assert.equal(
    projectExpandedDesktop.cameraTarget[0] < projectCollapsedDesktop.cameraTarget[0],
    true,
  );
  assert.equal(
    projectCollapsedDesktop.cameraTarget[0],
    seismos.zoomCameraTarget[0],
  );

  const mobileFrame360 = computeResponsiveCameraFrame(
    home.cameraPos,
    home.cameraTarget,
    360,
    800,
    false,
    false,
  );
  assert.equal(mobileFrame360.isMobilePortrait, true);
  assert.equal(mobileFrame360.fov, 54);
  assert.equal(mobileFrame360.cameraPos[2] > home.cameraPos[2] + 3.0, true);
  assert.equal(mobileFrame360.cameraTarget[1] < home.cameraTarget[1], true);
});

test('latLonToCartesian projects geographic coordinates onto sphere surface', () => {
  const radius = 2.0;
  const [x, y, z] = latLonToCartesian(0, 0, radius);
  const dist = Math.sqrt(x * x + y * y + z * z);
  assert.equal(Math.abs(dist - radius) < 0.01, true);
});

test('filterTimelineEntries and filterProjects return strictly verified subsets', () => {
  const internships = filterTimelineEntries('internship');
  assert.equal(internships.length, 3);

  const allProjects = filterProjects('all');
  assert.equal(allProjects.length, 4);

  const mlProjects = filterProjects('ml');
  assert.equal(mlProjects.length, 1);
  assert.equal(mlProjects[0].id, 'seismos');

  const biProjects = filterProjects('bi');
  assert.equal(biProjects.length, 3);
});

test('getProjectExecutiveBreakdown structures verified Problem, Approach, Tools, and Outcomes for all 4 projects', () => {
  for (const project of PROJECT_INSTALLATIONS) {
    const breakdown = getProjectExecutiveBreakdown(project);
    assert.equal(breakdown.problem.length > 20, true);
    assert.equal(breakdown.approach.length > 20, true);
    assert.equal(breakdown.tools.length >= 3, true);
    assert.equal(breakdown.outcomes.length >= 2, true);
    assert.equal(breakdown.primaryOutcome.length > 20, true);
  }
});

test('getFlightDurationSeconds respects prefers-reduced-motion', () => {
  assert.equal(getFlightDurationSeconds(true), 0.05);
  assert.equal(getFlightDurationSeconds(false), 1.05);
});

test('computeDevicePerformanceProfile selects high, medium, and low rendering profiles intelligently', () => {
  const desktopProfile = computeDevicePerformanceProfile({
    width: 1440,
    isSoftwareGl: false,
    deviceMemory: 8,
    hardwareConcurrency: 8,
    prefersReducedMotion: false,
  });
  assert.equal(desktopProfile.tier, 'high');
  assert.deepEqual(desktopProfile.dpr, [1, 2]);
  assert.equal(desktopProfile.particleCount, 120);
  assert.equal(desktopProfile.antialias, true);
  assert.equal(desktopProfile.enableEnvironmentMap, true);
  assert.equal(desktopProfile.animationScale, 1);

  const mobileProfile = computeDevicePerformanceProfile({
    width: 390,
    isSoftwareGl: false,
    deviceMemory: 6,
    hardwareConcurrency: 6,
    prefersReducedMotion: false,
  });
  assert.equal(mobileProfile.tier, 'medium');
  assert.deepEqual(mobileProfile.dpr, [1, 1.25]);
  assert.equal(mobileProfile.particleCount, 42);
  assert.equal(mobileProfile.antialias, true);

  const lowEndMobile = computeDevicePerformanceProfile({
    width: 360,
    isSoftwareGl: false,
    deviceMemory: 2,
    hardwareConcurrency: 2,
    prefersReducedMotion: true,
  });
  assert.equal(lowEndMobile.tier, 'low');
  assert.equal(lowEndMobile.dpr, 1);
  assert.equal(lowEndMobile.particleCount, 24);
  assert.equal(lowEndMobile.antialias, false);
  assert.equal(lowEndMobile.animationScale, 0);

  const softwareGlProfile = computeDevicePerformanceProfile({
    width: 1440,
    isSoftwareGl: true,
  });
  assert.equal(softwareGlProfile.tier, 'low');
  assert.equal(softwareGlProfile.dpr, 1);
  assert.equal(softwareGlProfile.enableEnvironmentMap, false);
});

